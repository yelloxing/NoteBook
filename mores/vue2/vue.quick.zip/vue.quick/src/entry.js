import Vue from 'vue';

//vue对象
var vm = new Vue({

    //匹配挂载点
    el: '#root',

    //启动渲染
    render: createElement => {
        return createElement('h1', '欢迎来到vue的世界！');
    }

});