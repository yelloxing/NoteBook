import Vue from 'vue';

//vue对象
var vm = new Vue({

    //匹配挂载点
    el: '#root',

    //数据
    data:{
        'infomation':'欢迎来到vue的世界！'
    }

});