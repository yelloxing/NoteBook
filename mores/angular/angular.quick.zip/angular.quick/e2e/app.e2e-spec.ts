import { Angular.QuickPage } from './app.po';

describe('angular.quick App', () => {
  let page: Angular.QuickPage;

  beforeEach(() => {
    page = new Angular.QuickPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
